﻿(function () {
    
    alert('test');

})();